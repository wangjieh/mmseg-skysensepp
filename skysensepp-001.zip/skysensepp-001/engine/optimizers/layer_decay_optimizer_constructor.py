"""Layer-wise learning-rate decay for SkySense++ MMSeg fine-tuning."""

from __future__ import annotations

import json
from typing import Dict, List, Optional, Sequence

from mmengine.dist import get_dist_info
from mmengine.logging import print_log
from mmengine.optim import DefaultOptimWrapperConstructor
from mmseg.registry import OPTIM_WRAPPER_CONSTRUCTORS


def _is_no_decay_param(name: str, param) -> bool:
    token_names = ('pos_embed', 'cls_token', 'mask_token', 'vocabulary_token',
                   'vocabulary_weight', 'absolute_pos_embed')
    return (len(param.shape) == 1 or name.endswith('.bias')
            or any(token in name for token in token_names)
            or '.norm' in name or '.ln' in name or 'norm_' in name)


def get_layer_id_for_vit(var_name: str, max_layer_id: int) -> int:
    """Layer id for SkySenseVisionTransformer parameters."""
    if not var_name.startswith('backbone.'):
        return max_layer_id
    name = var_name[len('backbone.'):]
    if (name.startswith('patch_embed') or name in
            ('cls_token', 'mask_token', 'pos_embed', 'vocabulary_token',
             'vocabulary_weight')):
        return 0
    if name.startswith('layers.'):
        try:
            layer_id = int(name.split('.')[1]) + 1
        except Exception:
            return max_layer_id
        return min(layer_id, max_layer_id)
    return max_layer_id


def get_layer_id_for_swin(var_name: str,
                          max_layer_id: int,
                          depths: Optional[Sequence[int]] = None) -> int:
    """Layer id for SkySenseSwinTransformerV2 parameters."""
    depths = list(depths or [2, 2, 18, 2])
    if not var_name.startswith('backbone.'):
        return max_layer_id
    name = var_name[len('backbone.'):]
    if (name.startswith('patch_embed') or name in
            ('mask_token', 'vocabulary_token', 'vocabulary_weight',
             'absolute_pos_embed')):
        return 0
    if name.startswith('stages.'):
        parts = name.split('.')
        try:
            stage_id = int(parts[1])
        except Exception:
            return max_layer_id
        if '.downsample.' in name:
            return min(1 + sum(depths[:stage_id]), max_layer_id)
        try:
            block_id = int(parts[3])
        except Exception:
            block_id = 0
        return min(1 + sum(depths[:stage_id]) + block_id, max_layer_id)
    if name.startswith(('norm', 'attn1', 'attn2', 'attn3', 'norm_attn')):
        return max_layer_id
    return max_layer_id


def infer_backbone_type(module) -> str:
    """Infer the layer-decay rule from the model backbone class name."""
    backbone = getattr(module, 'backbone', None)
    class_name = backbone.__class__.__name__ if backbone is not None else ''
    if 'Swin' in class_name:
        return 'swin'
    if 'VisionTransformer' in class_name or 'ViT' in class_name:
        return 'vit'
    return 'vit'


@OPTIM_WRAPPER_CONSTRUCTORS.register_module()
class LearningRateDecayOptimizerConstructor(DefaultOptimWrapperConstructor):
    """Optimizer constructor with layer-wise lr decay.

    Example config snippet::

        optim_wrapper = dict(
            type='OptimWrapper',
            optimizer=dict(type='AdamW', lr=6e-5, weight_decay=0.05),
            constructor='LearningRateDecayOptimizerConstructor',
            paramwise_cfg=dict(
                num_layers=24,
                decay_rate=0.9,
                decay_type='layer_wise',
                backbone_type='vit'))

    ``backbone_type`` can be ``'vit'``, ``'swin'`` or ``'auto'``.
    """

    def add_params(self, params: List[dict], module, **kwargs) -> None:
        parameter_groups: Dict[str, dict] = {}

        paramwise_cfg = self.paramwise_cfg or {}
        decay_rate = paramwise_cfg.get('decay_rate', 1.0)
        decay_type = paramwise_cfg.get('decay_type', 'layer_wise')
        backbone_type = paramwise_cfg.get('backbone_type', 'auto')
        if backbone_type == 'auto':
            backbone_type = infer_backbone_type(module)

        backbone = getattr(module, 'backbone', None)
        if paramwise_cfg.get('num_layers', None) is not None:
            backbone_layers = int(paramwise_cfg['num_layers'])
        elif backbone_type == 'swin' and backbone is not None:
            backbone_layers = int(sum(getattr(backbone, 'depths', [2, 2, 18, 2])))
        elif backbone is not None:
            backbone_layers = int(getattr(backbone, 'num_layers', 24))
        else:
            backbone_layers = 24
        max_layer_id = backbone_layers + 1
        swin_depths = paramwise_cfg.get('swin_depths', None)
        if swin_depths is None and backbone is not None:
            swin_depths = getattr(backbone, 'depths', None)

        print_log('Build LearningRateDecayOptimizerConstructor: '
                  f'decay_type={decay_type}, decay_rate={decay_rate}, '
                  f'backbone_type={backbone_type}, '
                  f'max_layer_id={max_layer_id}')

        for name, param in module.named_parameters():
            if not param.requires_grad:
                continue

            if _is_no_decay_param(name, param):
                decay_group = 'no_decay'
                this_weight_decay = 0.0
            else:
                decay_group = 'decay'
                this_weight_decay = self.base_wd

            if decay_type not in ('layer_wise', 'layer_wise_vit',
                                  'layer_wise_swin'):
                layer_id = max_layer_id
            elif backbone_type == 'swin' or decay_type == 'layer_wise_swin':
                layer_id = get_layer_id_for_swin(
                    name, max_layer_id=max_layer_id, depths=swin_depths)
            else:
                layer_id = get_layer_id_for_vit(
                    name, max_layer_id=max_layer_id)

            group_name = f'layer_{layer_id}_{decay_group}'
            if group_name not in parameter_groups:
                scale = decay_rate**(max_layer_id - layer_id)
                parameter_groups[group_name] = dict(
                    weight_decay=this_weight_decay,
                    params=[],
                    param_names=[],
                    lr_scale=scale,
                    group_name=group_name,
                    lr=scale * self.base_lr)

            parameter_groups[group_name]['params'].append(param)
            parameter_groups[group_name]['param_names'].append(name)

        rank, _ = get_dist_info()
        if rank == 0:
            display = {
                key: dict(
                    param_names=value['param_names'],
                    lr_scale=value['lr_scale'],
                    lr=value['lr'],
                    weight_decay=value['weight_decay'])
                for key, value in parameter_groups.items()
            }
            print_log('Param groups = '
                      f'{json.dumps(display, indent=2, ensure_ascii=False)}')
        params.extend(parameter_groups.values())


@OPTIM_WRAPPER_CONSTRUCTORS.register_module()
class SkySenseLayerDecayOptimizerConstructor(
        LearningRateDecayOptimizerConstructor):
    """Alias kept for explicit SkySense++ configs."""

    pass
