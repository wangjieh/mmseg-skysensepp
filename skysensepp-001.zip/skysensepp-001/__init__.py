# Copyright (c) OpenMMLab. All rights reserved.
# Copyright (c) SkySense++ contributors.
"""SkySense++ project plugin for MMSegmentation 1.x.

Place this directory under ``mmsegmentation/projects/skysensepp`` and import it
from config files via ``custom_imports``.
"""

from . import engine, models  # noqa: F401,F403

__all__ = ['models', 'engine']
