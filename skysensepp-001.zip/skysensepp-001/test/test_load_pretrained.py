# -*- coding: utf-8 -*-
"""
Test whether SkySense++ official release weights can be loaded correctly.

Place this file at:
    mmsegmentation/projects/skysensepp/test/test_load_pretrained.py

Example:
    python projects/skysensepp/test/test_load_pretrained.py ^
        --s1 F:/PythonProject/Skysense++/SkySensePlusPlus-main/pretrain/skysensepp_release_s1.pth ^
        --s2 F:/PythonProject/Skysense++/SkySensePlusPlus-main/pretrain/skysensepp_release_s2.pth ^
        --hr F:/PythonProject/Skysense++/SkySensePlusPlus-main/pretrain/skysensepp_release_hr.pth

Optional forward test for S1/S2:
    python projects/skysensepp/test/test_load_pretrained.py --forward-vit
"""

from __future__ import annotations

import argparse
import gc
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import torch


# -------------------------------------------------------------------------
# Make sure `import skysensepp` works when this script is run from mmseg root.
# Expected structure:
#   mmsegmentation/
#   └── projects/
#       └── skysensepp/
#           ├── __init__.py
#           └── test/
#               └── test_load_pretrained.py
# -------------------------------------------------------------------------
THIS_FILE = Path(__file__).resolve()
SKYSENSEPP_DIR = THIS_FILE.parents[1]
PROJECTS_DIR = SKYSENSEPP_DIR.parent
MMSEG_ROOT = PROJECTS_DIR.parent

for p in [str(PROJECTS_DIR), str(MMSEG_ROOT)]:
    if p not in sys.path:
        sys.path.insert(0, p)


import skysensepp  # noqa: F401,E402
from skysensepp.models.backbones import (  # noqa: E402
    SkySenseSwinTransformerV2,
    SkySenseVisionTransformer,
)
from skysensepp.models.utils import (  # noqa: E402
    clean_state_dict,
    load_checkpoint_state_dict,
    prepare_skysense_state_dict,
)


BENIGN_MISSING_KEYWORDS = (
    "relative_position_index",
    "relative_coords_table",
    "attn_mask",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Test loading SkySense++ release pretrained weights."
    )

    parser.add_argument(
        "--s1",
        type=str,
        default=None,
        help="Path to skysensepp_release_s1.pth.",
    )
    parser.add_argument(
        "--s2",
        type=str,
        default=None,
        help="Path to skysensepp_release_s2.pth.",
    )
    parser.add_argument(
        "--hr",
        type=str,
        default=None,
        help="Path to skysensepp_release_hr.pth.",
    )

    parser.add_argument(
        "--only",
        nargs="+",
        choices=["s1", "s2", "hr"],
        default=["s1", "s2", "hr"],
        help="Only test selected weights.",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cpu",
        help="cpu, cuda, cuda:0, etc.",
    )
    parser.add_argument(
        "--forward-vit",
        action="store_true",
        help="Run a tiny forward test for S1/S2 ViT after loading.",
    )
    parser.add_argument(
        "--forward-hr",
        action="store_true",
        help=(
            "Run a forward test for HR SwinV2. This is memory-heavy and is "
            "disabled by default."
        ),
    )
    parser.add_argument(
        "--vit-img-size",
        type=int,
        default=16,
        help=(
            "Input image size used to instantiate S1/S2 ViT. "
            "Default 16 matches release pos_embed grid 4x4 with patch_size=4."
        ),
    )
    parser.add_argument(
        "--hr-img-size",
        type=int,
        default=256,
        help="Input image size used to instantiate HR SwinV2.",
    )
    parser.add_argument(
        "--max-list",
        type=int,
        default=30,
        help="Maximum number of missing/unexpected keys to print.",
    )
    return parser.parse_args()


def resolve_weight_path(user_path: Optional[str], filename: str) -> Path:
    if user_path is not None:
        path = Path(user_path).expanduser()
        if not path.is_file():
            raise FileNotFoundError(f"Weight file not found: {path}")
        return path

    candidates = [
        MMSEG_ROOT / "pretrain" / filename,
        SKYSENSEPP_DIR / "pretrain" / filename,
        Path.cwd() / "pretrain" / filename,
        Path.cwd() / filename,
    ]

    for path in candidates:
        if path.is_file():
            return path

    msg = "\n".join(str(p) for p in candidates)
    raise FileNotFoundError(
        f"Cannot find {filename}. Please pass its path explicitly.\n"
        f"Searched:\n{msg}"
    )


def get_device(device_str: str) -> torch.device:
    if device_str.startswith("cuda") and not torch.cuda.is_available():
        print("[WARN] CUDA is not available. Fallback to CPU.")
        return torch.device("cpu")
    return torch.device(device_str)


def count_params(model: torch.nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


def shape_of(x) -> Tuple[int, ...]:
    return tuple(x.shape)


def print_key_list(title: str, keys: Iterable[str], max_list: int) -> None:
    keys = list(keys)
    print(f"{title}: {len(keys)}")
    for key in keys[:max_list]:
        print(f"  - {key}")
    if len(keys) > max_list:
        print(f"  ... and {len(keys) - max_list} more")


def split_missing_keys(missing_keys: List[str]) -> Tuple[List[str], List[str]]:
    benign = []
    suspicious = []
    for key in missing_keys:
        if any(word in key for word in BENIGN_MISSING_KEYWORDS):
            benign.append(key)
        else:
            suspicious.append(key)
    return benign, suspicious


def build_s1_model() -> SkySenseVisionTransformer:
    return SkySenseVisionTransformer(
        img_size=(16, 16),
        patch_size=4,
        in_channels=2,
        embed_dims=1024,
        num_layers=24,
        num_heads=16,
        mlp_ratio=4,
        out_indices=(5, 11, 17, 23),
        qkv_bias=True,
        drop_rate=0.0,
        attn_drop_rate=0.0,
        drop_path_rate=0.0,
        norm_cfg=dict(type="LN", eps=1e-6),
        vocabulary_size=64,
        init_cfg=None,
    )


def build_s2_model() -> SkySenseVisionTransformer:
    return SkySenseVisionTransformer(
        img_size=(16, 16),
        patch_size=4,
        in_channels=10,
        embed_dims=1024,
        num_layers=24,
        num_heads=16,
        mlp_ratio=4,
        out_indices=(5, 11, 17, 23),
        qkv_bias=True,
        drop_rate=0.0,
        attn_drop_rate=0.0,
        drop_path_rate=0.0,
        norm_cfg=dict(type="LN", eps=1e-6),
        vocabulary_size=64,
        init_cfg=None,
    )


def build_hr_model(hr_img_size: int) -> SkySenseSwinTransformerV2:
    return SkySenseSwinTransformerV2(
        arch="huge",
        img_size=hr_img_size,
        patch_size=4,
        in_channels=3,
        window_size=8,
        out_indices=(0, 1, 2, 3),
        use_attn=True,
        merge_stage=2,
        vocabulary_size=64,
        init_cfg=None,
    )


def load_and_report(
    name: str,
    model: torch.nn.Module,
    checkpoint_path: Path,
    device: torch.device,
    pos_embed_key: str,
    patch_embed_key: str,
    pos_embed_grid: Optional[Tuple[int, int]],
    drop_relative_position_buffers: bool,
    max_list: int,
    forward_input_shape: Optional[Tuple[int, int, int, int]] = None,
) -> None:
    print("\n" + "=" * 88)
    print(f"[{name}]")
    print(f"Checkpoint: {checkpoint_path}")
    print(f"Model params: {count_params(model):,}")

    model_state = model.state_dict()

    raw_state = load_checkpoint_state_dict(str(checkpoint_path))
    clean_state = clean_state_dict(raw_state)

    shape_mismatch_before = []
    for key, value in clean_state.items():
        if key in model_state and hasattr(value, "shape"):
            if value.shape != model_state[key].shape:
                shape_mismatch_before.append(
                    (key, shape_of(value), shape_of(model_state[key]))
                )

    print(f"Checkpoint tensors after key cleaning: {len(clean_state)}")
    print(f"Shape mismatches before adaptation: {len(shape_mismatch_before)}")
    for key, ckpt_shape, model_shape in shape_mismatch_before[:max_list]:
        print(f"  - {key}: ckpt={ckpt_shape}, model={model_shape}")
    if len(shape_mismatch_before) > max_list:
        print(f"  ... and {len(shape_mismatch_before) - max_list} more")

    prepared_state = prepare_skysense_state_dict(
        clean_state,
        model_state,
        pos_embed_key=pos_embed_key,
        patch_embed_key=patch_embed_key,
        pos_embed_grid=pos_embed_grid,
        interpolate_mode="bicubic",
        input_adapt_mode="auto",
        drop_relative_position_buffers=drop_relative_position_buffers,
        verbose=True,
    )

    loaded_keys = [
        key
        for key, value in prepared_state.items()
        if key in model_state and hasattr(value, "shape")
        and value.shape == model_state[key].shape
    ]
    unexpected_before_load = [
        key for key in prepared_state.keys() if key not in model_state
    ]
    final_shape_mismatch = [
        key
        for key, value in prepared_state.items()
        if key in model_state
        and hasattr(value, "shape")
        and value.shape != model_state[key].shape
    ]

    print(f"Prepared tensors: {len(prepared_state)}")
    print(f"Loadable tensors: {len(loaded_keys)}")
    print(f"Unexpected tensors before load: {len(unexpected_before_load)}")
    print(f"Final shape mismatches after adaptation: {len(final_shape_mismatch)}")

    model.to(device)
    incompatible = model.load_state_dict(prepared_state, strict=False)

    missing_keys = list(incompatible.missing_keys)
    unexpected_keys = list(incompatible.unexpected_keys)
    benign_missing, suspicious_missing = split_missing_keys(missing_keys)

    print_key_list("Missing keys, suspicious", suspicious_missing, max_list)
    print_key_list("Missing keys, benign", benign_missing, max_list)
    print_key_list("Unexpected keys", unexpected_keys, max_list)

    if final_shape_mismatch:
        print("[FAIL] There are still shape-mismatched tensors after adaptation.")
    elif len(loaded_keys) == 0:
        print("[FAIL] No tensors were loaded.")
    elif suspicious_missing or unexpected_keys:
        print("[WARN] Weight loading finished, but please inspect missing/unexpected keys.")
    else:
        print("[OK] Weight loading looks clean.")

    if forward_input_shape is not None:
        print(f"Forward test input shape: {forward_input_shape}")
        model.eval()
        dummy = torch.randn(*forward_input_shape, device=device)
        with torch.inference_mode():
            outputs = model(dummy)

        if isinstance(outputs, torch.Tensor):
            outputs = (outputs,)

        print(f"Forward outputs: {len(outputs)}")
        for i, out in enumerate(outputs):
            print(f"  output[{i}]: {tuple(out.shape)}")

        del dummy, outputs

    model.cpu()
    del raw_state, clean_state, prepared_state, model
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()


def main() -> None:
    args = parse_args()
    device = get_device(args.device)

    print(f"mmseg root inferred as: {MMSEG_ROOT}")
    print(f"skysensepp dir inferred as: {SKYSENSEPP_DIR}")
    print(f"device: {device}")

    weights: Dict[str, Path] = {}
    if "s1" in args.only:
        weights["s1"] = resolve_weight_path(args.s1, "skysensepp_release_s1.pth")
    if "s2" in args.only:
        weights["s2"] = resolve_weight_path(args.s2, "skysensepp_release_s2.pth")
    if "hr" in args.only:
        weights["hr"] = resolve_weight_path(args.hr, "skysensepp_release_hr.pth")

    if "s1" in args.only:
        model = build_s1_model()
        vit_grid = (args.vit_img_size // 4, args.vit_img_size // 4)
        load_and_report(
            name="SkySense++ S1 ViT",
            model=model,
            checkpoint_path=weights["s1"],
            device=device,
            pos_embed_key="pos_embed",
            patch_embed_key="patch_embed.projection.weight",
            pos_embed_grid=vit_grid,
            drop_relative_position_buffers=False,
            max_list=args.max_list,
            forward_input_shape=(1, 2, args.vit_img_size, args.vit_img_size)
            if args.forward_vit else None,
        )

    if "s2" in args.only:
        model = build_s2_model()
        vit_grid = (args.vit_img_size // 4, args.vit_img_size // 4)
        load_and_report(
            name="SkySense++ S2 ViT",
            model=model,
            checkpoint_path=weights["s2"],
            device=device,
            pos_embed_key="pos_embed",
            patch_embed_key="patch_embed.projection.weight",
            pos_embed_grid=vit_grid,
            drop_relative_position_buffers=False,
            max_list=args.max_list,
            forward_input_shape=(1, 10, args.vit_img_size, args.vit_img_size)
            if args.forward_vit else None,
        )

    if "hr" in args.only:
        model = build_hr_model(args.hr_img_size)
        load_and_report(
            name="SkySense++ HR SwinV2",
            model=model,
            checkpoint_path=weights["hr"],
            device=device,
            pos_embed_key="absolute_pos_embed",
            patch_embed_key="patch_embed.projection.weight",
            pos_embed_grid=None,
            drop_relative_position_buffers=True,
            max_list=args.max_list,
            forward_input_shape=(1, 3, args.hr_img_size, args.hr_img_size)
            if args.forward_hr else None,
        )

    print("\nAll selected tests finished.")


if __name__ == "__main__":
    main()
