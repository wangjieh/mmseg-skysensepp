"""Checkpoint helpers for SkySense++ release weights.

The official SkySense++ release provides three backbone-only ``state_dict``
files:

- ``skysensepp_release_s1.pth``: ViT-MSL, 2 input channels.
- ``skysensepp_release_s2.pth``: ViT-MSL, 10 input channels.
- ``skysensepp_release_hr.pth``: SwinV2-MSL Huge, 3 input channels.

These helpers adapt those weights to MMSegmentation fine-tuning models without
requiring the original AntMMF pre-training pipeline.
"""

from __future__ import annotations

import math
from collections import OrderedDict
from typing import Dict, Iterable, Mapping, MutableMapping, Optional, Tuple

import torch
import torch.nn.functional as F
from mmengine.logging import MMLogger, print_log
from mmengine.runner.checkpoint import CheckpointLoader


def _get_logger():
    """Return the current MMEngine logger if it exists."""
    try:
        return MMLogger.get_current_instance()
    except Exception:
        return None


def _log(message: str) -> None:
    """Log a message without assuming a runner has already been built."""
    logger = _get_logger()
    if logger is not None:
        logger.info(message)
    else:
        print(message)


def load_checkpoint_state_dict(checkpoint: str,
                               map_location: str = 'cpu') -> OrderedDict:
    """Load a checkpoint and return its state dict.

    Args:
        checkpoint: Local path or URL accepted by MMEngine's
            :class:`CheckpointLoader`.
        map_location: Torch map location.

    Returns:
        OrderedDict: The actual parameter dictionary.
    """
    ckpt = CheckpointLoader.load_checkpoint(
        checkpoint, map_location=map_location, logger=_get_logger())
    if isinstance(ckpt, Mapping) and 'state_dict' in ckpt:
        state_dict = ckpt['state_dict']
    elif isinstance(ckpt, Mapping) and 'model' in ckpt:
        state_dict = ckpt['model']
    else:
        state_dict = ckpt

    if not isinstance(state_dict, Mapping):
        raise TypeError(
            f'Checkpoint {checkpoint!r} does not contain a state_dict-like '
            f'object, but got {type(state_dict)}.')
    return OrderedDict(state_dict)


def clean_state_dict(state_dict: Mapping[str, torch.Tensor],
                     prefixes: Iterable[str] = (
                         'module.', 'model.', 'backbone.', 'backbone_s1.',
                         'backbone_s2.', 'backbone_hr.')) -> OrderedDict:
    """Remove common wrappers/prefixes from checkpoint keys.

    The official release files have no prefix, but this function also supports
    checkpoints saved from ``DataParallel`` / ``DistributedDataParallel`` and
    from MMSegmentation ``EncoderDecoder`` models.
    """
    cleaned = OrderedDict()
    for key, value in state_dict.items():
        new_key = key
        changed = True
        while changed:
            changed = False
            for prefix in prefixes:
                if new_key.startswith(prefix):
                    new_key = new_key[len(prefix):]
                    changed = True
        cleaned[new_key] = value
    return cleaned


def _infer_square_shape(num_tokens: int) -> Tuple[int, int]:
    size = int(math.sqrt(num_tokens))
    if size * size != num_tokens:
        raise ValueError(
            f'Cannot infer a square positional-embedding shape from '
            f'{num_tokens} tokens. Please provide a checkpoint whose pos_embed '
            f'grid is square or pre-resize it manually.')
    return size, size


def resize_pos_embed_without_cls(pos_embed: torch.Tensor,
                                 target_shape: Tuple[int, int],
                                 source_shape: Optional[Tuple[int,
                                                              int]] = None,
                                 mode: str = 'bicubic') -> torch.Tensor:
    """Resize ViT positional embeddings that do not contain a class token.

    SkySense++ ViT-MSL release weights keep ``cls_token`` as a parameter, but
    their ``pos_embed`` contains only patch-grid tokens, for example
    ``[1, 16, 1024]`` for a 4x4 grid. This differs from common ViT checkpoints
    whose pos_embed is ``[1, 1 + H*W, C]``.
    """
    if pos_embed.ndim != 3:
        raise ValueError(f'pos_embed must be 3D, got shape {pos_embed.shape}.')
    if source_shape is None:
        source_shape = _infer_square_shape(pos_embed.shape[1])
    src_h, src_w = source_shape
    dst_h, dst_w = target_shape
    if (src_h, src_w) == (dst_h, dst_w):
        return pos_embed

    pos = pos_embed.reshape(1, src_h, src_w,
                            pos_embed.shape[-1]).permute(0, 3, 1, 2)
    pos = F.interpolate(pos, size=(dst_h, dst_w), mode=mode,
                        align_corners=False)
    pos = pos.flatten(2).transpose(1, 2).contiguous()
    return pos


def adapt_input_conv(weight: torch.Tensor,
                     target_in_channels: int,
                     mode: str = 'auto') -> torch.Tensor:
    """Adapt a convolution weight to a new number of input channels.

    Args:
        weight: Convolution weight in ``[out_channels, in_channels, kH, kW]``.
        target_in_channels: Desired input channel count.
        mode: Adaptation strategy. ``'auto'`` and ``'slice_mean'`` copy the
            overlapping channels and fill extra channels with the source mean.
            ``'repeat'`` repeats channels and rescales by the source/target
            ratio. ``'slice'`` simply keeps the first target channels and fails
            if the target has more channels than the source.
    """
    if weight.ndim != 4:
        raise ValueError(
            f'Patch embedding weight must be 4D, got {weight.shape}.')
    source_in_channels = weight.shape[1]
    if source_in_channels == target_in_channels:
        return weight

    if mode in ('auto', 'slice_mean'):
        new_weight = weight.new_zeros(weight.shape[0], target_in_channels,
                                      weight.shape[2], weight.shape[3])
        common = min(source_in_channels, target_in_channels)
        new_weight[:, :common] = weight[:, :common]
        if target_in_channels > source_in_channels:
            mean_channel = weight.mean(dim=1, keepdim=True)
            new_weight[:, source_in_channels:] = mean_channel.repeat(
                1, target_in_channels - source_in_channels, 1, 1)
        return new_weight

    if mode == 'repeat':
        repeat = int(math.ceil(target_in_channels / source_in_channels))
        new_weight = weight.repeat(1, repeat, 1, 1)[:, :target_in_channels]
        new_weight = new_weight * (source_in_channels / target_in_channels)
        return new_weight

    if mode == 'slice':
        if target_in_channels > source_in_channels:
            raise ValueError(
                'slice mode cannot increase input channels from '
                f'{source_in_channels} to {target_in_channels}.')
        return weight[:, :target_in_channels]

    raise ValueError(f'Unknown input adaptation mode: {mode!r}.')


def drop_unwanted_keys(state_dict: MutableMapping[str, torch.Tensor],
                       drop_relative_position_buffers: bool = True) -> None:
    """Delete keys that should be re-initialized by OpenMMLab modules."""
    if not drop_relative_position_buffers:
        return
    for key in list(state_dict.keys()):
        if ('relative_position_index' in key
                or 'relative_coords_table' in key):
            del state_dict[key]


def prepare_skysense_state_dict(state_dict: Mapping[str, torch.Tensor],
                                model_state_dict: Mapping[str, torch.Tensor],
                                pos_embed_key: str = 'pos_embed',
                                patch_embed_key: str =
                                'patch_embed.projection.weight',
                                pos_embed_grid: Optional[Tuple[int,
                                                               int]] = None,
                                interpolate_mode: str = 'bicubic',
                                input_adapt_mode: str = 'auto',
                                drop_relative_position_buffers: bool = True,
                                verbose: bool = True) -> OrderedDict:
    """Adapt a SkySense++ release state dict for a target model.

    The function performs four conservative operations:

    1. strip common prefixes;
    2. resize ViT-MSL ``pos_embed`` if needed;
    3. adapt ``patch_embed.projection.weight`` when input channels differ;
    4. remove remaining shape-mismatched tensors before non-strict loading.
    """
    state_dict = clean_state_dict(state_dict)
    drop_unwanted_keys(state_dict, drop_relative_position_buffers)

    if pos_embed_key in state_dict and pos_embed_key in model_state_dict:
        src = state_dict[pos_embed_key]
        dst = model_state_dict[pos_embed_key]
        if src.shape != dst.shape:
            if src.ndim == 3 and dst.ndim == 3 and src.shape[-1] == dst.shape[-1]:
                dst_grid = pos_embed_grid or _infer_square_shape(dst.shape[1])
                try:
                    state_dict[pos_embed_key] = resize_pos_embed_without_cls(
                        src, target_shape=dst_grid, mode=interpolate_mode)
                    if verbose:
                        _log('Resized SkySense++ pos_embed from '
                             f'{tuple(src.shape)} to '
                             f'{tuple(state_dict[pos_embed_key].shape)}.')
                except Exception as exc:
                    if verbose:
                        _log('Failed to resize pos_embed; it will be skipped. '
                             f'Reason: {exc}')
                    del state_dict[pos_embed_key]
            else:
                if verbose:
                    _log('Skip incompatible pos_embed: checkpoint '
                         f'{tuple(src.shape)} vs model {tuple(dst.shape)}.')
                del state_dict[pos_embed_key]

    if patch_embed_key in state_dict and patch_embed_key in model_state_dict:
        src = state_dict[patch_embed_key]
        dst = model_state_dict[patch_embed_key]
        if src.shape != dst.shape:
            if (src.ndim == 4 and dst.ndim == 4
                    and src.shape[0] == dst.shape[0]
                    and src.shape[2:] == dst.shape[2:]):
                state_dict[patch_embed_key] = adapt_input_conv(
                    src, dst.shape[1], mode=input_adapt_mode)
                if verbose:
                    _log('Adapted patch_embed input channels from '
                         f'{src.shape[1]} to {dst.shape[1]}.')
            else:
                if verbose:
                    _log('Skip incompatible patch_embed weight: checkpoint '
                         f'{tuple(src.shape)} vs model {tuple(dst.shape)}.')
                del state_dict[patch_embed_key]

    # Remove all remaining incompatible tensors. This avoids shape mismatch
    # errors in PyTorch's load_state_dict while keeping strict=False behavior.
    for key in list(state_dict.keys()):
        if key in model_state_dict and state_dict[key].shape != model_state_dict[key].shape:
            if verbose:
                _log('Skip incompatible tensor '
                     f'{key}: checkpoint {tuple(state_dict[key].shape)} vs '
                     f'model {tuple(model_state_dict[key].shape)}.')
            del state_dict[key]
    return OrderedDict(state_dict)
