"""PixelShuffle upsampling head used by SkySense++.

The original project used ``UPHead`` as a lightweight reconstruction head. This
MMSegmentation version subclasses ``BaseDecodeHead`` so it can be used directly
as a semantic segmentation decode head.
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
from mmcv.cnn import ConvModule
from mmengine.model.weight_init import kaiming_init, trunc_normal_
from mmseg.models.decode_heads.decode_head import BaseDecodeHead
from mmseg.registry import MODELS


@MODELS.register_module()
class UPHead(BaseDecodeHead):
    """A simple 1x1-conv + PixelShuffle segmentation head.

    Args:
        up_scale: PixelShuffle scale. For SkySense++ ViT with patch size 4,
            ``up_scale=4`` maps patch-grid logits back to image resolution.
        conv_before_shuffle: Whether to add a ConvModule before the final
            1x1 projection. If ``channels`` equals ``in_channels`` this can be
            disabled for a closer match to the original SkySense++ UPHead.
    """

    def __init__(self,
                 up_scale: int = 4,
                 conv_before_shuffle: bool = False,
                 init_cfg: Optional[dict] = None,
                 **kwargs):
        # Backward-compatible aliases from the original SkySense++ UPHead.
        in_dim = kwargs.pop('in_dim', None)
        out_dim = kwargs.pop('out_dim', None)
        if in_dim is not None and 'in_channels' not in kwargs:
            kwargs['in_channels'] = in_dim
        if out_dim is not None and 'num_classes' not in kwargs:
            kwargs['num_classes'] = out_dim
        if 'channels' not in kwargs and 'in_channels' in kwargs:
            in_channels = kwargs['in_channels']
            kwargs['channels'] = in_channels[-1] if isinstance(
                in_channels, (list, tuple)) else in_channels

        super().__init__(init_cfg=init_cfg, **kwargs)
        self.up_scale = up_scale
        self.conv_before_shuffle = conv_before_shuffle

        if conv_before_shuffle:
            self.pre_conv = ConvModule(
                self.in_channels,
                self.channels,
                kernel_size=3,
                padding=1,
                conv_cfg=self.conv_cfg,
                norm_cfg=self.norm_cfg,
                act_cfg=self.act_cfg)
            in_dim = self.channels
        else:
            self.pre_conv = nn.Identity()
            if isinstance(self.in_channels, (list, tuple)):
                raise TypeError(
                    'UPHead with conv_before_shuffle=False expects a single '
                    'input feature. Set input_transform or '
                    'conv_before_shuffle=True for multiple features.')
            in_dim = self.in_channels

        self.decoder = nn.Sequential(
            nn.Conv2d(
                in_channels=in_dim,
                out_channels=(up_scale**2) * self.num_classes,
                kernel_size=1),
            nn.PixelShuffle(up_scale))

        # BaseDecodeHead creates conv_seg for normal heads. It is unused here.
        self.conv_seg = nn.Identity()

    def init_weights(self) -> None:
        super().init_weights()
        for module in self.modules():
            if isinstance(module, nn.Linear):
                trunc_normal_(module.weight, std=.02)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.Conv2d):
                kaiming_init(module, mode='fan_in', bias=0.)

    def forward(self, inputs) -> torch.Tensor:
        x = self._transform_inputs(inputs)
        if isinstance(x, (list, tuple)):
            # If input_transform='multiple_select' was used, take the last
            # selected feature by default. Most SkySense++ ViT configs use a
            # single in_index for this head.
            x = x[-1]
        x = self.pre_conv(x)
        if self.dropout is not None:
            x = self.dropout(x)
        x = self.decoder(x)
        return x
