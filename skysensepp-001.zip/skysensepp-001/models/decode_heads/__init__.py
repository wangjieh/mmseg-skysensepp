"""Decode heads exposed by the SkySense++ project."""

from .up_head import UPHead

__all__ = ['UPHead']
