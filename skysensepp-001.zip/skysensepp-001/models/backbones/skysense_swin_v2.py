"""SkySense++ SwinV2-MSL backbone for MMSegmentation fine-tuning.

The HR release checkpoint is based on SwinTransformerV2-MSL Huge. For
downstream segmentation we reuse MMPreTrain's SwinTransformerV2 implementation
and add the SkySense++-specific parameters so the official release state_dict
can be loaded cleanly.
"""

from __future__ import annotations

import warnings
from typing import Optional

import torch
import torch.nn as nn
from mmcv.cnn import build_norm_layer
from mmcv.cnn.bricks.transformer import MultiheadAttention
from mmengine.model.weight_init import trunc_normal_
from mmengine.runner.checkpoint import load_state_dict
from mmseg.registry import MODELS

try:
    from mmpretrain.models.backbones.swin_transformer_v2 import (  # type: ignore  # noqa: E501
        SwinTransformerV2)
except Exception as exc:  # pragma: no cover - exercised in user env only.
    SwinTransformerV2 = None
    _MMPRETRAIN_IMPORT_ERROR = exc
else:
    _MMPRETRAIN_IMPORT_ERROR = None

from ..utils import load_checkpoint_state_dict, prepare_skysense_state_dict


class ProjMHSA(nn.Module):
    """Projection + MHSA + projection block used by SkySense++ MSL."""

    def __init__(self,
                 embed_dims: int,
                 proj_dims: int,
                 num_heads: int = 16,
                 batch_first: bool = True,
                 bias: bool = True):
        super().__init__()
        self.proj_in = nn.Linear(embed_dims, proj_dims)
        self.attn = MultiheadAttention(
            embed_dims=proj_dims,
            num_heads=num_heads,
            batch_first=batch_first,
            bias=bias)
        self.proj_out = nn.Linear(proj_dims, embed_dims)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj_in(x)
        x = self.attn(x, identity=x)
        x = self.proj_out(x)
        return x


@MODELS.register_module()
class SkySenseSwinTransformerV2(SwinTransformerV2 if SwinTransformerV2 is not None else nn.Module):  # type: ignore[misc]
    """SkySense++ HR SwinV2-MSL backbone.

    Args follow MMPreTrain's ``SwinTransformerV2``. The extra SkySense++ MSL
    arguments are accepted for checkpoint compatibility. During downstream
    semantic segmentation, ``forward`` is inherited from MMPreTrain and only
    consumes image tensors.
    """

    def __init__(self,
                 arch: str = 'huge',
                 img_size=256,
                 patch_size: int = 4,
                 in_channels: int = 3,
                 vocabulary_size: int = 64,
                 use_attn: bool = True,
                 merge_stage: int = 2,
                 with_cls_pos: bool = False,
                 input_adapt_mode: str = 'auto',
                 pretrained: Optional[str] = None,
                 init_cfg: Optional[dict] = None,
                 **kwargs):
        if SwinTransformerV2 is None:
            raise ImportError(
                'SkySenseSwinTransformerV2 requires mmpretrain. The user '
                'environment declared mmpretrain==1.2.0, but importing '
                f'`mmpretrain.models.backbones.SwinTransformerV2` failed: '
                f'{_MMPRETRAIN_IMPORT_ERROR}')

        if pretrained is not None:
            warnings.warn('`pretrained` is deprecated. Use '
                          '`init_cfg=dict(type="Pretrained", checkpoint=...)`.',
                          DeprecationWarning)
            init_cfg = dict(type='Pretrained', checkpoint=pretrained)
        self.skysense_init_cfg = init_cfg
        self.input_adapt_mode = input_adapt_mode
        self.use_attn = use_attn
        self.merge_stage = merge_stage
        self.with_cls_pos = with_cls_pos
        self.skysense_vocabulary_size = vocabulary_size + 1

        # The old SkySense++ code used is_post_norm=True. MMPreTrain 1.x uses
        # use_post_norm=True in PatchMerging. Keep the MMPreTrain default unless
        # the caller explicitly passes stage_cfgs, and normalize old keys.
        stage_cfgs = kwargs.get('stage_cfgs', dict())
        if isinstance(stage_cfgs, dict):
            downsample_cfg = stage_cfgs.get('downsample_cfg', None)
            if isinstance(downsample_cfg, dict) and 'is_post_norm' in downsample_cfg:
                downsample_cfg = dict(downsample_cfg)
                downsample_cfg['use_post_norm'] = downsample_cfg.pop('is_post_norm')
                stage_cfgs = dict(stage_cfgs)
                stage_cfgs['downsample_cfg'] = downsample_cfg
        kwargs['stage_cfgs'] = stage_cfgs

        super().__init__(
            arch=arch,
            img_size=img_size,
            patch_size=patch_size,
            in_channels=in_channels,
            init_cfg=None,
            **kwargs)

        self.mask_token = nn.Parameter(torch.zeros(1, 1, self.embed_dims))
        self.vocabulary_token = nn.Parameter(
            torch.zeros(self.skysense_vocabulary_size, self.embed_dims))
        self.vocabulary_weight = nn.Parameter(
            torch.zeros(1, patch_size * patch_size))

        if self.use_attn:
            # These dimensions match the official HR Huge release checkpoint.
            self.attn1 = ProjMHSA(352, 256, num_heads=16)
            self.attn2 = ProjMHSA(704, 512, num_heads=16)
            self.attn3 = ProjMHSA(1408, 1024, num_heads=16)
            self.attention_blocks = [self.attn1, self.attn2, self.attn3]
            self.norm_attn = build_norm_layer(dict(type='LN'), 1408)[1]

    def init_weights(self) -> None:
        if (isinstance(self.skysense_init_cfg, dict)
                and self.skysense_init_cfg.get('type') == 'Pretrained'):
            checkpoint = self.skysense_init_cfg['checkpoint']
            state_dict = load_checkpoint_state_dict(checkpoint)
            state_dict = prepare_skysense_state_dict(
                state_dict,
                self.state_dict(),
                pos_embed_key='absolute_pos_embed',
                patch_embed_key='patch_embed.projection.weight',
                pos_embed_grid=getattr(self, 'patch_resolution', None),
                interpolate_mode=getattr(self, 'interpolate_mode', 'bicubic'),
                input_adapt_mode=self.input_adapt_mode,
                drop_relative_position_buffers=True)
            load_state_dict(self, state_dict, strict=False)
            return

        super().init_weights()
        trunc_normal_(self.mask_token, std=.02)
        trunc_normal_(self.vocabulary_token, std=.02)
        nn.init.zeros_(self.vocabulary_weight)
