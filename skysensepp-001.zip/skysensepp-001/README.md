# SkySense++ MMSegmentation Project Plugin

This package migrates the **fine-tuning / semantic segmentation** parts of SkySense++ into the OpenMMLab `projects/` style.

Target environment:

- `mmcv==2.2.0`
- `mmengine==0.10.7`
- `mmsegmentation==1.2.2`
- `mmpretrain==1.2.0`

It does **not** migrate SkySense++ pre-training, annotation reconstruction, few-shot Flood-3i predictor, pre-training datasets, or custom dataset configs.

## Install / placement

Copy the `skysensepp` directory to:

```text
mmsegmentation/projects/skysensepp
```

Your config can import it with either of the following, depending on where you launch training:

```python
custom_imports = dict(
    imports=['projects.skysensepp'],
    allow_failed_imports=False)
```

or, if the config is inside `projects/skysensepp` and that folder is on `PYTHONPATH`:

```python
custom_imports = dict(imports=['skysensepp'], allow_failed_imports=False)
```

## Registered components

### Backbones

- `SkySenseVisionTransformer`
  - For `skysensepp_release_s1.pth` and `skysensepp_release_s2.pth`.
  - Keeps `cls_token`, `mask_token`, `vocabulary_token`, and `vocabulary_weight` so the official MSL release weights can load.
  - Uses image-only downstream forward and returns NCHW feature maps.

- `SkySenseSwinTransformerV2`
  - For `skysensepp_release_hr.pth`.
  - Reuses `mmpretrain.models.backbones.SwinTransformerV2` and adds SkySense++ MSL parameters.

### Decode head

- `UPHead`
  - A simple `BaseDecodeHead` wrapper around `1x1 Conv + PixelShuffle`.
  - Optional; you can also use MMSegmentation's official `UPerHead`, `FCNHead`, etc.

### Optimizer constructors

- `LearningRateDecayOptimizerConstructor`
- `SkySenseLayerDecayOptimizerConstructor`

Both support SkySense++ ViT and SwinV2 backbones.

## S2 example model snippet

```python
custom_imports = dict(imports=['projects.skysensepp'], allow_failed_imports=False)

model = dict(
    type='EncoderDecoder',
    data_preprocessor=dict(type='SegDataPreProcessor'),
    backbone=dict(
        type='SkySenseVisionTransformer',
        img_size=(256, 256),
        patch_size=4,
        in_channels=10,
        embed_dims=1024,
        num_layers=24,
        num_heads=16,
        mlp_ratio=4,
        out_indices=(5, 11, 17, 23),
        qkv_bias=True,
        drop_rate=0.1,
        norm_cfg=dict(type='LN', eps=1e-6),
        init_cfg=dict(
            type='Pretrained',
            checkpoint='pretrain/skysensepp_release_s2.pth')),
    neck=dict(
        type='MultiLevelNeck',
        in_channels=[1024, 1024, 1024, 1024],
        out_channels=512,
        scales=[1, 1, 1, 1]),
    decode_head=dict(
        type='UPerHead',
        in_channels=[512, 512, 512, 512],
        in_index=[0, 1, 2, 3],
        channels=512,
        num_classes=2,
        pool_scales=(1, 2, 3, 6),
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0)),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'))
```

## S1 example difference

```python
backbone=dict(
    type='SkySenseVisionTransformer',
    img_size=(256, 256),
    patch_size=4,
    in_channels=2,
    embed_dims=1024,
    num_layers=24,
    num_heads=16,
    out_indices=(5, 11, 17, 23),
    init_cfg=dict(type='Pretrained', checkpoint='pretrain/skysensepp_release_s1.pth'))
```

## HR example difference

```python
backbone=dict(
    type='SkySenseSwinTransformerV2',
    arch='huge',
    img_size=256,
    patch_size=4,
    in_channels=3,
    window_size=8,
    out_indices=(0, 1, 2, 3),
    use_attn=True,
    vocabulary_size=64,
    init_cfg=dict(type='Pretrained', checkpoint='pretrain/skysensepp_release_hr.pth'))
```

For HR SwinV2 Huge, expected feature channels are approximately `[352, 704, 1408, 2816]`.

## Layer-wise decay example

```python
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=6e-5, weight_decay=0.05),
    constructor='LearningRateDecayOptimizerConstructor',
    paramwise_cfg=dict(
        num_layers=24,
        decay_rate=0.9,
        decay_type='layer_wise',
        backbone_type='vit'))
```

For HR SwinV2:

```python
paramwise_cfg=dict(
    decay_rate=0.9,
    decay_type='layer_wise_swin',
    backbone_type='swin',
    swin_depths=[2, 2, 18, 2])
```

## Notes

- If your Sentinel-2 channel count differs from the release weight, `patch_embed.projection.weight` is adapted automatically. Existing channels are copied; extra channels are initialized with the mean source channel.
- `pos_embed` in S1/S2 release weights is resized automatically to your configured `img_size // patch_size` grid.
- Datasets and configs are intentionally not included, per the current migration scope.
