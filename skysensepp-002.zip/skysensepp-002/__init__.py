# Copyright (c) OpenMMLab. All rights reserved.
# Copyright (c) SkySense++ contributors.
"""SkySense++ project plugin for MMSegmentation 1.x.

Place this directory under ``mmsegmentation/projects/skysensepp`` and import it
from config files via ``custom_imports``.

This project package registers:
- SkySense++ backbones / decode heads
- optimizer constructors
- training hooks
- project datasets / transforms
"""

from . import datasets, engine, models  # noqa: F401,F403

__all__ = ['models', 'engine', 'datasets']
