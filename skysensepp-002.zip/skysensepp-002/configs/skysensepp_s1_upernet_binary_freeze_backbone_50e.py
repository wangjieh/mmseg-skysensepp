# SkySense++ S1 ViT + UPerNet for a binary 256x256 folder dataset.
#
# Dataset layout:
#   D:/dataset/
#     train/
#       palsar/sat, palsar/gt, sentinel/sat, sentinel/gt
#     test/
#       palsar/sat, palsar/gt, sentinel/sat, sentinel/gt
#
# Masks are 3-channel black/white images:
#   (0, 0, 0)       -> class 0 background
#   (255, 255, 255) -> class 1 foreground

custom_imports = dict(
    imports=['projects.skysensepp'],
    allow_failed_imports=False)

default_scope = 'mmseg'

data_root = 'D:/dataset'
s1_pretrained = 'pretrain/skysensepp_release_s1.pth'

crop_size = (256, 256)
num_classes = 2

# Images are 8-bit 3-channel. S1 release weights are 2-channel, but the
# SkySenseVisionTransformer checkpoint loader will adapt patch_embed from
# 2 channels to 3 channels automatically.
mean = [127.5, 127.5, 127.5]
std = [127.5, 127.5, 127.5]

norm_cfg = dict(type='BN', requires_grad=True)

data_preprocessor = dict(
    type='SegDataPreProcessor',
    mean=mean,
    std=std,
    bgr_to_rgb=True,
    pad_val=0,
    seg_pad_val=255,
    size=crop_size)

model = dict(
    type='EncoderDecoder',
    data_preprocessor=data_preprocessor,
    pretrained=None,
    backbone=dict(
        type='SkySenseVisionTransformer',
        img_size=crop_size,
        patch_size=4,
        in_channels=3,
        embed_dims=1024,
        num_layers=24,
        num_heads=16,
        mlp_ratio=4,
        out_indices=(5, 11, 17, 23),
        qkv_bias=True,
        drop_rate=0.1,
        attn_drop_rate=0.0,
        drop_path_rate=0.1,
        norm_cfg=dict(type='LN', eps=1e-6, requires_grad=True),
        act_cfg=dict(type='GELU'),
        norm_eval=False,
        vocabulary_size=64,
        init_cfg=dict(type='Pretrained', checkpoint=s1_pretrained)),
    neck=dict(
        type='MultiLevelNeck',
        in_channels=[1024, 1024, 1024, 1024],
        out_channels=1024,
        scales=[4, 2, 1, 0.5]),
    decode_head=dict(
        type='UPerHead',
        in_channels=[1024, 1024, 1024, 1024],
        in_index=[0, 1, 2, 3],
        channels=512,
        pool_scales=(1, 2, 3, 6),
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(
            type='CrossEntropyLoss',
            use_sigmoid=False,
            loss_weight=1.0)),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'))

train_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='LoadRGBBinaryAnnotations', threshold=127),
    dict(type='RandomFlip', prob=0.5, direction='horizontal'),
    dict(type='RandomFlip', prob=0.5, direction='vertical'),
    dict(type='PackSegInputs'),
]

test_pipeline = [
    dict(type='LoadImageFromFile'),
    dict(type='LoadRGBBinaryAnnotations', threshold=127),
    dict(type='PackSegInputs'),
]

train_dataloader = dict(
    batch_size=4,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=True),
    dataset=dict(
        type='SkySenseBinaryFolderDataset',
        data_root=data_root,
        split='train',
        satellites=('palsar', 'sentinel'),
        pipeline=train_pipeline))

val_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type='SkySenseBinaryFolderDataset',
        data_root=data_root,
        split='test',
        satellites=('palsar', 'sentinel'),
        pipeline=test_pipeline))

test_dataloader = val_dataloader

val_evaluator = dict(
    type='IoUMetric',
    iou_metrics=['mIoU', 'mFscore'])
test_evaluator = val_evaluator

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=50, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(
        type='AdamW',
        lr=6e-5,
        betas=(0.9, 0.999),
        weight_decay=0.01),
    paramwise_cfg=dict(
        custom_keys=dict(
            pos_embed=dict(decay_mult=0.0),
            cls_token=dict(decay_mult=0.0),
            mask_token=dict(decay_mult=0.0),
            vocabulary_token=dict(decay_mult=0.0),
            vocabulary_weight=dict(decay_mult=0.0),
            norm=dict(decay_mult=0.0))))

param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=1e-6,
        by_epoch=False,
        begin=0,
        end=500),
    dict(
        type='PolyLR',
        eta_min=0.0,
        power=1.0,
        begin=0,
        end=50,
        by_epoch=True),
]

default_hooks = dict(
    timer=dict(type='IterTimerHook'),
    logger=dict(type='LoggerHook', interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type='ParamSchedulerHook'),
    checkpoint=dict(
        type='CheckpointHook',
        by_epoch=True,
        interval=1,
        max_keep_ckpts=3,
        save_best='mIoU'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    visualization=dict(type='SegVisualizationHook'))

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0),
    dist_cfg=dict(backend='nccl'))

vis_backends = [dict(type='LocalVisBackend')]
visualizer = dict(
    type='SegLocalVisualizer',
    vis_backends=vis_backends,
    name='visualizer')

log_processor = dict(by_epoch=True)
log_level = 'INFO'
load_from = None
resume = False
randomness = dict(seed=0)

# Train 50 epochs with the backbone frozen. Only neck/decode head and other
# non-backbone parameters are updated.
custom_hooks = [
    dict(
        type='FreezeBackboneHook',
        module_names=('backbone',),
        begin_epoch=0,
        end_epoch=50,
        set_eval=True,
        priority='VERY_HIGH')
]

work_dir = './work_dirs/skysensepp_s1_upernet_binary_freeze_backbone_50e'
