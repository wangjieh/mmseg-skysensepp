"""Freeze/unfreeze selected modules by epoch."""

from __future__ import annotations

from typing import Sequence, Union

from mmengine.hooks import Hook
from mmengine.model import is_model_wrapper

try:
    from mmseg.registry import HOOKS
except Exception:  # pragma: no cover
    from mmengine.registry import HOOKS


def _as_tuple(value: Union[str, Sequence[str]]) -> tuple:
    if isinstance(value, str):
        return (value,)
    return tuple(value)


@HOOKS.register_module()
class FreezeBackboneHook(Hook):
    """Freeze modules for a specified epoch interval.

    Epoch indexing follows MMEngine's zero-based ``runner.epoch``. Therefore
    ``begin_epoch=0, end_epoch=10`` freezes epochs 1-10 and unfreezes from
    epoch 11.

    Args:
        module_names: Module attribute names under the segmentor. For normal
            MMSeg EncoderDecoder models, use ``('backbone',)``.
        begin_epoch: First epoch index to freeze.
        end_epoch: Exclusive end epoch index. ``None`` means freeze until the
            end of training.
        set_eval: Whether to call ``eval()`` for frozen modules each epoch.
        verbose: Whether to log freeze/unfreeze state changes.
    """

    priority = 'VERY_HIGH'

    def __init__(self,
                 module_names: Union[str, Sequence[str]] = ('backbone',),
                 begin_epoch: int = 0,
                 end_epoch: int | None = None,
                 set_eval: bool = True,
                 verbose: bool = True) -> None:
        self.module_names = _as_tuple(module_names)
        self.begin_epoch = begin_epoch
        self.end_epoch = end_epoch
        self.set_eval = set_eval
        self.verbose = verbose
        self._last_frozen_state = None

    def _unwrap_model(self, model):
        if is_model_wrapper(model):
            return model.module
        return model

    def _get_module(self, model, module_name: str):
        module = model
        for attr in module_name.split('.'):
            if not hasattr(module, attr):
                raise AttributeError(
                    f'Model has no module path {module_name!r}. Missing '
                    f'attribute: {attr!r}')
            module = getattr(module, attr)
        return module

    def _should_freeze(self, epoch: int) -> bool:
        if epoch < self.begin_epoch:
            return False
        if self.end_epoch is None:
            return True
        return epoch < self.end_epoch

    def _set_requires_grad(self, runner, frozen: bool) -> None:
        model = self._unwrap_model(runner.model)

        for module_name in self.module_names:
            module = self._get_module(model, module_name)
            if frozen and self.set_eval:
                module.eval()
            for param in module.parameters():
                param.requires_grad = not frozen

        if self.verbose and frozen != self._last_frozen_state:
            state = 'frozen' if frozen else 'unfrozen'
            runner.logger.info(
                f'FreezeBackboneHook: modules {self.module_names} are '
                f'{state} at epoch {runner.epoch + 1}.')
            self._last_frozen_state = frozen

    def before_train(self, runner) -> None:
        self._set_requires_grad(runner, self._should_freeze(runner.epoch))

    def before_train_epoch(self, runner) -> None:
        self._set_requires_grad(runner, self._should_freeze(runner.epoch))
