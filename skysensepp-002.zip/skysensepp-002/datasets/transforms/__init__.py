"""Custom transforms for SkySense++ project datasets."""

from .loading import LoadRGBBinaryAnnotations

__all__ = ['LoadRGBBinaryAnnotations']
