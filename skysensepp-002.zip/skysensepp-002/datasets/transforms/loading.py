"""Loading transforms for SkySense++ project datasets."""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

import mmcv
import numpy as np
from mmengine.fileio import get
from mmseg.registry import TRANSFORMS


@TRANSFORMS.register_module()
class LoadRGBBinaryAnnotations:
    """Load a 3-channel black/white mask as a binary segmentation map.

    The dataset masks are 3-channel images where black ``(0, 0, 0)`` means
    background and white ``(255, 255, 255)`` means foreground. This transform
    converts them to a single-channel ``uint8`` map with labels:

    - 0: background
    - 1: foreground

    If a mask is already single-channel, it is thresholded directly.
    """

    def __init__(self,
                 threshold: int = 127,
                 foreground_label: int = 1,
                 background_label: int = 0,
                 ignore_index: Optional[int] = None,
                 backend_args: Optional[dict] = None) -> None:
        self.threshold = threshold
        self.foreground_label = foreground_label
        self.background_label = background_label
        self.ignore_index = ignore_index
        self.backend_args = backend_args

    def __call__(self, results: dict) -> dict:
        if 'seg_map_path' not in results:
            raise KeyError('`seg_map_path` is required by '
                           'LoadRGBBinaryAnnotations.')

        img_bytes = get(results['seg_map_path'], backend_args=self.backend_args)
        gt = mmcv.imfrombytes(img_bytes, flag='unchanged')

        if gt is None:
            raise ValueError(f'Failed to load mask: {results["seg_map_path"]}')

        if gt.ndim == 3:
            # Channel order does not matter for black/white masks.
            gray = gt[..., :3].astype(np.float32).mean(axis=2)
        elif gt.ndim == 2:
            gray = gt.astype(np.float32)
        else:
            raise ValueError(
                f'Unsupported mask shape {gt.shape} for '
                f'{results["seg_map_path"]}')

        seg = np.full(
            gray.shape, self.background_label, dtype=np.uint8)
        seg[gray > self.threshold] = self.foreground_label

        # Optional support for ignored pixels if the user later adds them.
        if self.ignore_index is not None:
            seg[gray == self.ignore_index] = self.ignore_index

        results['gt_seg_map'] = seg
        results.setdefault('seg_fields', [])
        results['seg_fields'].append('gt_seg_map')
        return results

    def __repr__(self) -> str:
        return (self.__class__.__name__ +
                f'(threshold={self.threshold}, '
                f'foreground_label={self.foreground_label}, '
                f'background_label={self.background_label}, '
                f'ignore_index={self.ignore_index})')
