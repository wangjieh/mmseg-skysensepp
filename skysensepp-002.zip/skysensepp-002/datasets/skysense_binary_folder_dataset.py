"""Binary folder dataset for paired remote-sensing images and RGB masks.

Expected data layout::

    D:/dataset/
      train/
        palsar/
          sat/
          gt/
        sentinel/
          sat/
          gt/
      test/
        palsar/
          sat/
          gt/
        sentinel/
          sat/
          gt/

The image and mask files are matched by file stem. For example:
``sat/0001.png`` will be paired with ``gt/0001.png`` if both exist, even if
extensions differ.
"""

from __future__ import annotations

import os
import os.path as osp
from typing import Dict, List, Optional, Sequence, Tuple, Union

from mmseg.datasets.basesegdataset import BaseSegDataset
from mmseg.registry import DATASETS


IMG_EXTENSIONS = (
    '.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff',
    '.PNG', '.JPG', '.JPEG', '.BMP', '.TIF', '.TIFF',
)


def _to_tuple(value: Optional[Union[str, Sequence[str]]]) -> Tuple[str, ...]:
    if value is None:
        return tuple()
    if isinstance(value, str):
        return (value,)
    return tuple(value)


@DATASETS.register_module()
class SkySenseBinaryFolderDataset(BaseSegDataset):
    """Dataset that scans ``split/satellite/sat`` and ``split/satellite/gt``.

    Args:
        data_root: Root directory, e.g. ``D:/dataset``.
        split: ``train`` or ``test``.
        satellites: Satellite folders to include. Use ``('palsar',
            'sentinel')`` to merge both domains into one dataset.
        img_dir_name: Image subdirectory name. Default: ``sat``.
        ann_dir_name: Mask subdirectory name. Default: ``gt``.
        img_suffix: Optional allowed image suffixes. If ``None``, common image
            suffixes are used.
        seg_map_suffix: Optional allowed mask suffixes. If ``None``, common
            image suffixes are used.
        recursive: Whether to scan recursively under ``sat`` and ``gt``.
    """

    METAINFO = dict(
        classes=('background', 'foreground'),
        palette=[[0, 0, 0], [255, 255, 255]])

    def __init__(self,
                 split: str = 'train',
                 satellites: Union[str, Sequence[str]] = ('palsar',
                                                          'sentinel'),
                 img_dir_name: str = 'sat',
                 ann_dir_name: str = 'gt',
                 img_suffix: Optional[Union[str, Sequence[str]]] = None,
                 seg_map_suffix: Optional[Union[str, Sequence[str]]] = None,
                 recursive: bool = False,
                 **kwargs) -> None:
        self.split_folder = split
        self.satellites = _to_tuple(satellites)
        self.img_dir_name = img_dir_name
        self.ann_dir_name = ann_dir_name
        self.allowed_img_suffixes = _to_tuple(img_suffix) or IMG_EXTENSIONS
        self.allowed_seg_suffixes = _to_tuple(seg_map_suffix) or IMG_EXTENSIONS
        self.recursive = recursive

        # BaseSegDataset still expects these args, but this dataset overrides
        # load_data_list and therefore does not use the default suffix matching.
        super().__init__(
            img_suffix='',
            seg_map_suffix='',
            reduce_zero_label=False,
            **kwargs)

    def _scan_files(self, folder: str,
                    suffixes: Sequence[str]) -> Dict[str, str]:
        files: Dict[str, str] = {}
        if not osp.isdir(folder):
            raise FileNotFoundError(f'Directory does not exist: {folder}')

        if self.recursive:
            walker = os.walk(folder)
            for root, _, filenames in walker:
                for filename in filenames:
                    if filename.endswith(tuple(suffixes)):
                        path = osp.join(root, filename)
                        rel = osp.relpath(path, folder)
                        stem = osp.splitext(rel)[0].replace('\\', '/')
                        files[stem] = path
        else:
            for filename in os.listdir(folder):
                path = osp.join(folder, filename)
                if osp.isfile(path) and filename.endswith(tuple(suffixes)):
                    stem = osp.splitext(filename)[0]
                    files[stem] = path

        return files

    def load_data_list(self) -> List[dict]:
        data_list: List[dict] = []
        root = self.data_root or ''

        for satellite in self.satellites:
            sat_root = osp.join(root, self.split_folder, satellite)
            img_dir = osp.join(sat_root, self.img_dir_name)
            ann_dir = osp.join(sat_root, self.ann_dir_name)

            img_files = self._scan_files(img_dir, self.allowed_img_suffixes)
            ann_files = self._scan_files(ann_dir, self.allowed_seg_suffixes)

            common_stems = sorted(set(img_files.keys()) & set(ann_files.keys()))
            missing_anns = sorted(set(img_files.keys()) - set(ann_files.keys()))
            missing_imgs = sorted(set(ann_files.keys()) - set(img_files.keys()))

            if len(common_stems) == 0:
                raise RuntimeError(
                    f'No matched image/mask pairs found for satellite '
                    f'{satellite!r}. img_dir={img_dir}, ann_dir={ann_dir}')

            if missing_anns:
                print(f'[SkySenseBinaryFolderDataset] {satellite}: '
                      f'{len(missing_anns)} images have no matching masks. '
                      f'Example: {missing_anns[:3]}')
            if missing_imgs:
                print(f'[SkySenseBinaryFolderDataset] {satellite}: '
                      f'{len(missing_imgs)} masks have no matching images. '
                      f'Example: {missing_imgs[:3]}')

            for stem in common_stems:
                data_info = dict(
                    img_path=img_files[stem],
                    seg_map_path=ann_files[stem],
                    satellite=satellite,
                    img_id=f'{satellite}/{stem}',
                    label_map=self.label_map,
                    reduce_zero_label=self.reduce_zero_label,
                    seg_fields=[])
                data_list.append(data_info)

        return data_list
